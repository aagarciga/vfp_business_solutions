<?php
/**
 * Created by PhpStorm.
 * User: Victor
 * Date: 12/01/2016
 * Time: 14:58
 * Project:  VFP Business Series
 * Copyright: 2014. VFP Business Solutions, LLC
 */

$View->Template('Master');