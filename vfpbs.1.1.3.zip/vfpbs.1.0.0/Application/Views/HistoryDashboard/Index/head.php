<link rel="stylesheet" href="<?php echo $View->PublicVendorContext('bootstrap-3/css/bootstrap-select.min.css'); ?>">
<link rel="stylesheet" href="<?php echo $View->PublicVendorContext('bootstrap-3/css/daterangepicker-bs3.min.css'); ?>">
<link rel="stylesheet" href="<?php echo $View->PublicVendorContext('dropzone/css/dropzone.min.css'); ?>">
<link rel="stylesheet" href="<?php echo $View->PublicVendorContext('jstree/themes/default/style.min.css'); ?>">
<link rel="stylesheet" href="<?php echo $View->PublicVendorContext('responsive-tables/responsive-tables.css'); ?>">
<link rel="stylesheet" href="<?php echo $View->StylesContext('HistoryDashboard/index.min.css'); ?>">

<link rel="stylesheet" href="<?php echo $View->PublicVendorContext('lightbox2-master/dist/css/lightbox.min.css')?>">