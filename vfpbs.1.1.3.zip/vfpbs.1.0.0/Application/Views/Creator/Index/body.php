
<h1>Dandelion MVC Creator</h1>
<nav>
    <ul>
        <li>
            <a href="<?php echo $View->Href('creator', 'controllers')?>">Controllers</a>
        </li>
        <li>
            <a href="<?php echo $View->Href('creator', 'actions')?>">Actions</a>
        </li>
    </ul>
</nav>