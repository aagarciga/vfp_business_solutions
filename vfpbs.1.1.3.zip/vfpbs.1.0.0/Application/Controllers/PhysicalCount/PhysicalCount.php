<?php
/**
 * Project:  VFP Business Series
 * Copyright: 2014. VFP Business Solutions, LLC
 */

namespace Dandelion\MVC\Application\Controllers;

use Dandelion\MVC\Application\Controllers\DatActionsController;

/**
 * VFP Business Series Physical Count Controller
 * @name PhysicalCount
 */
class PhysicalCount extends DatActionsController {

}