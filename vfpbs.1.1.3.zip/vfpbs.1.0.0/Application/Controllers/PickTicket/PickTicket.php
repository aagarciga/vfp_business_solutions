<?php
/**
 * Project:  VFP Business Series
 * Copyright: 2014. VFP Business Solutions, LLC
 */

namespace Dandelion\MVC\Application\Controllers;

use Dandelion\MVC\Application\Controllers\DatActionsController;

/**
 * VFP PickTicket Series Shipment Controller
 * @name PickTicket
 */
class PickTicket extends DatActionsController {
    
}