<?php
/**
 * Project:  VFP Business Series
 * Copyright: 2014. VFP Business Solutions, LLC
 */

namespace Dandelion\MVC\Application\Controllers;

/**
 * Class EquipmentHistoryDashboard
 * @package Dandelion\MVC\Application\Controllers
 */
class EquipmentHistoryDashboard extends DatDashboardController
{

}