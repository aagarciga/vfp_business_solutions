<?php
/**
 * Project:  VFP Business Series
 * Copyright: 2014. VFP Business Solutions, LLC
 */

/**
 * Class Helpers for static helpers methods
 */
class Helpers
{
    static function HelperMethod1(){
        return "I'm a Helper method";
    }
}